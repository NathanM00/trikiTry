package servertriki;

public class PrincipalServer {
	
	
    public static void main(String[] args) {
    	Comunicacion com = new Comunicacion();
    	com.start();
    }
	

}
