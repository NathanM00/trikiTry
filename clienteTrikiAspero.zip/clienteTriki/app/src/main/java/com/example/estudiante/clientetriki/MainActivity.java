package com.example.estudiante.clientetriki;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btn_1is, btn_1ce, btn_1de;
    Button btn_2is, btn_2ce, btn_2de;
    Button btn_3is, btn_3ce, btn_3de;
    int contador, turno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_1is = findViewById(R.id.btn_1is);
        btn_2is = findViewById(R.id.btn_2is);
        btn_3is = findViewById(R.id.btn_3is);

        btn_1ce = findViewById(R.id.btn_1ce);
        btn_2ce = findViewById(R.id.btn_2ce);
        btn_3ce = findViewById(R.id.btn_3ce);


        btn_1de = findViewById(R.id.btn_1de);
        btn_2de = findViewById(R.id.btn_2de);
        btn_3de = findViewById(R.id.btn_3de);

        btn_1is.setOnClickListener(this);
        btn_2is.setOnClickListener(this);
        btn_3is.setOnClickListener(this);

        btn_1ce.setOnClickListener(this);
        btn_2ce.setOnClickListener(this);
        btn_3ce.setOnClickListener(this);

        btn_1de.setOnClickListener(this);
        btn_2de.setOnClickListener(this);
        btn_3de.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        contador ++;
        turno = contador%2;

        if(turno == 1){
            impresion('x',view);

        } else{

            impresion(' ',view);
        }

    }

    public void impresion(char letra, View v){

        if(v.getId() == R.id.btn_1is){
            btn_1is.setText(letra+"");
            btn_1is.setEnabled(false);
        }
        else if(v.getId() == R.id.btn_2is){
            btn_2is.setText(letra+"");
            btn_2is.setEnabled(false);
        }
        else if(v.getId() == R.id.btn_3is){
            btn_3is.setText(letra+"");
            btn_3is.setEnabled(false);
        }
        else if(v.getId() == R.id.btn_1ce){
            btn_1ce.setText(letra+"");
            btn_1ce.setEnabled(false);
        }
        else if(v.getId() == R.id.btn_2ce){
            btn_2ce.setText(letra+"");
            btn_2ce.setEnabled(false);
        }
        else if(v.getId() == R.id.btn_3ce){
            btn_3ce.setText(letra+"");
            btn_3ce.setEnabled(false);
        }
        else if(v.getId() == R.id.btn_1de){
            btn_1de.setText(letra+"");
            btn_1de.setEnabled(false);
        }
        else if(v.getId() == R.id.btn_2de){
            btn_2de.setText(letra+"");
            btn_2de.setEnabled(false);
        }
        else if(v.getId() == R.id.btn_3de){
            btn_3de.setText(letra+"");
            btn_3de.setEnabled(false);
        }
    }
}


